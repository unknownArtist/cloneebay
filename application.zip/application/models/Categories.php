<?php

class Application_Model_Categories extends Zend_Db_Table_Abstract
{
	protected $_name = "category";
	protected $_primary = "cat_id";


}

