<?php

class Application_Model_Countries extends Zend_Db_Table_Abstract
{
	protected $_name = "iso_countries";
	protected $_primary = "countryId";


}

