<?php

class Application_Model_Bids extends Zend_Db_Table_Abstract
{
	protected $_name = "tbl_bids";
	protected $_primary = "bids_id";


}

