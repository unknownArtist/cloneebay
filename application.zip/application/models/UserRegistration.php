<?php

class Application_Model_UserRegistration extends Zend_Db_Table_Abstract
{

	protected $_name = "user_registration";
	protected $_primary = "id";
}

