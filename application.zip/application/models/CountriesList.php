<?php

class Application_Model_CountriesList
{


}

